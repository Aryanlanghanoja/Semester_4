/*
 * Task_1.c
 *
 * Created: 08-02-2024 21:05:51
 * Author : Aryan
 */ 

 /*
  * Task_1.c
  *
  * Created: 08-02-2024 21:54:55
  * Author : Aryan
  */

#include <avr/io.h>
#include <avr/delay.h>
#include <util/delay.h>
#define F_CPU 16000000UL;

void Pattern_0() {
	PORTA = 0xFF;
	_delay_ms(500);
	PORTA = 0x00;
	_delay_ms(500);
}

void Pattern_1() {
	PORTA = 0xAA;
	_delay_ms(500);
	PORTA = 0x55;
	_delay_ms(500);
}

void Pattern_2() {
	PORTA = 0xF0;
	_delay_ms(500);
	PORTA = 0x0F;
	_delay_ms(500);
}

void Pattern_3() {
	PORTA = 0x00;
	_delay_ms(500);
	PORTA = 0x01;

	while (PORTA != 0x00) {
		_delay_ms(500);
		PORTA = PORTA << 1;

		if (PORTA == 0xFF) {
			PORTA == 0x01;
		}
	}
}

void Pattern_4() {
	PORTA = 0xFF;
	_delay_ms(500);
	int Sequences[8] = { 0xFE,0xFD,0xFB,0xF7,0xEF,0xDF,0xBF,0x7F };

	int i = 0;
	while (i <= 9) {
		PORTA = Sequences[i];
		_delay_ms(500);

		if (i == 9) {
			i = -1;
			PORTA = 0xFF;
			_delay_ms(500);
		}
		i++;
	}
}

void Pattern_5() {
	PORTA = 0x00;
	_delay_ms(500);
	PORTA = 0x80;

	while (PORTA != 0x00) {
		_delay_ms(500);
		PORTA = PORTA >> 1;

		if (PORTA == 0x01) {
			PORTA == 0x80;
		}
	}
}

void Pattern_6() {
	PORTA = 0x00;
	_delay_ms(500);
	int Sequences[7] = { 0x81,0x42,0x24,0x18,0x24,0x42,0x81 };

	int i = 0;
	while (i <= 7) {
		PORTA = Sequences[i];
		_delay_ms(500);
		i++;

		if (i == 8) {
			i = 0;
		}
	}
}

void Pattern_7() {
	PORTA = 0xFF;
	_delay_ms(500);
	int Sequences[7] = { 0x7E,0xBD,0xDB,0xE7,0xDB,0xBD,0x7E };

	int i = 0;
	while (i <= 7) {
		PORTA = Sequences[i];
		_delay_ms(500);
		i++;

		if (i == 8) {
			i = 0;
		}
	}
}

void Pattern_8() {
	PORTA = 0x00;
	_delay_ms(500);
	PORTA = 0X01 ;
	_delay_ms(500);
	
	while(1) {
		PORTA = PORTA << 1 ;
		_delay_ms(500);
		
		if (PORTA == 0x80) {
			PORTA = 0x01 ;
			_delay_ms(500);
		}
	}
}

void Pattern_9() {
	PORTA = 0xFF;
	_delay_ms(500);
	PORTA = 0x80 ;
	_delay_ms(500);
	
	while (1) {
		PORTA	=	PORTA >> 1 ;
		_delay_ms(500);
		
		if (PORTA == 0x01) {
			PORTA = 0x80 ;
			_delay_ms(500);
		}
	}
}

int main(void)
{
	/* Replace with your application code */
	DDRA = 0xFF;
	DDRB = 0x00;
	DDRB = DDRB | 0xF0;

	while (1) {

		if (PINB == 0x00) {
			Pattern_0();
		}

		if (PINB == 0x01) {
			Pattern_1();
		}

		if (PINB == 0x02) {
			Pattern_2();
		}

		if (PINB == 0x03) {
			Pattern_3();
		}

		if (PINB == 0x04) {
			Pattern_4();
		}

		if (PINB == 0x05) {
			Pattern_5();
		}

		if (PINB == 0x06) {
			Pattern_6();
		}

		if (PINB == 0x07) {
			Pattern_7();
		}

		if (PINB == 0x08) {
			Pattern_8();
		}

		if (PINB == 0x09) {
			Pattern_9();
		}
	}
}


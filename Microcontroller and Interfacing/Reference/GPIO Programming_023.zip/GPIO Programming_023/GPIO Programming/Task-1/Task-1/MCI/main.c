#include <avr/io.h>
#include <util/delay.h>
#define F_CPU 8000000UL // Define CPU frequency

int main(void) {
	DDRA = 0xFF; // Set PORTA as output

	while(1) {
		// Pattern 1: All LEDs ON
		PORTA = 0xFF;
		_delay_ms(500);

		// Pattern 2: 
		PORTA = 0x0b01010101;
		_delay_ms(500);

		// Pattern 3: Alternating ON/OFF
		PORTA = 0x0b10101010;
		_delay_ms(500);

		// Pattern 4: Blinking from left to right
		for (int i = 0; i < 8; i++) {
			PORTA = (1 << i);
			_delay_ms(100);
		}

		// Pattern 5: Blinking from right to left
		for (int i = 7; i >= 0; i--) {
			PORTA = (1 << i);
			_delay_ms(100);
		}

		// Pattern 6: Alternating Blinking
		for (int i = 0; i < 4; i++) {
			PORTA = 0xAA;
			_delay_ms(200);
			PORTA = 0x55;
			_delay_ms(200);
		}

		// Pattern 7: Flashing in a sequence
		for (int i = 0; i < 8; i++) {
			PORTA = (1 << i);
			_delay_ms(200);
			PORTA = 0x00;
			_delay_ms(200);
		}

		// Pattern 8: Two LEDs ON, Others OFF
		for (int i = 0; i < 8; i += 2) {
			PORTA = (1 << i);
			_delay_ms(200);
			PORTA = 0x00;
			_delay_ms(200);
		}

		// Pattern 9: LEDs ON in a rotating pattern
		for (int i = 0; i < 8; i++) {
			PORTA = (1 << i);
			_delay_ms(200);
		}

		// Pattern 10: LEDs OFF in a rotating pattern
		for (int i = 7; i >= 0; i--) {
			PORTA = ~(1 << i);
			_delay_ms(200);
		}
	}
	return 0;
}

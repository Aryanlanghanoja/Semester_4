#include<avr/io.h>
#include<util/delay.h>
void main()
{
	DDRD=0xFF;
	while(1)
	{
		PORTD=0b00000010; // for rotate clock wise
		_delay_ms(2000);
		PORTD=0b00000001; // for anti clockwise
		_delay_ms(2000);
	}
}

/*

#include <inttypes.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/sleep.h>
#include <avr/delay.h>
#define LCD PORTD
#define EN 0
#define RW 1
#define RS 2



void lcdcmd(unsigned char cmd){

PORTB &= ~(1<<RS);
PORTB &= ~(1<<RW);
LCD = cmd & 0xF0;
PORTB |= (1<<EN);
_delay_ms(1);
PORTB &= ~(1<<EN);
LCD =cmd<<4;
PORTB |= (1<<EN);
_delay_ms(1);
PORTB &= ~(1<<EN);

}

void lcddata(unsigned char data){

PORTB |= (1<<RS);
PORTB &= ~(1<<RW);
LCD= data& 0xF0;
PORTB |= (1<<EN);
_delay_ms(1);
PORTB &= ~(1<<EN);
LCD =data<<4;
PORTB |= (1<<EN);
_delay_ms(1);
PORTB &= ~(1<<EN);

}

void lcd_init(){

DDRD = 0xFF;
DDRB = 0xFF;
PORTB &= ~(1<<EN);
lcdcmd(0x33);
lcdcmd(0x32);
lcdcmd(0x28); //lcd in 4 bit configuration

lcdcmd(0x0E); //display on corsor on
lcdcmd(0x01); //clear lcd

_delay_ms(2);
}

void lcd_print(char *str){

unsigned char i=0;

while(str[i]!=0){
   lcddata(str[i]);
   i++;
}

}


int main()
 { 

   lcd_init();
   lcd_print("Krish Mamtora");
   
   while (1){
   
 

   
   }
   return 0;
 }
 
*/
 

#include <avr/io.h>
#include <util/delay.h>
#include <stdlib.h>

#define LCD PORTD
#define EN 0
#define RW 1
#define RS 2

void ADC_Init() {
    DDRA = 0x00;
    ADCSRA = 0x87;
    ADMUX = 0x40;
}

int ADC_Read(char channel) {
    ADMUX = 0x40 | (channel & 0x07);   
    ADCSRA |= (1<<ADSC);             
    while (!(ADCSRA & (1<<ADIF)));
    ADCSRA |= (1<<ADIF);             
    _delay_ms(1);                     
    return ADCW;                       
}

void lcdcmd(unsigned char cmd) {
    PORTB &= ~(1<<RS);
    PORTB &= ~(1<<RW);
    LCD = cmd & 0xF0;
    PORTB |= (1<<EN);
    _delay_ms(1);
    PORTB &= ~(1<<EN);
    LCD = cmd << 4;
    PORTB |= (1<<EN);
    _delay_ms(1);
    PORTB &= ~(1<<EN);
}

void lcddata(unsigned char data) {
    PORTB |= (1<<RS);
    PORTB &= ~(1<<RW);
    LCD = data & 0xF0;
    PORTB |= (1<<EN);
    _delay_ms(1);
    PORTB &= ~(1<<EN);
    LCD = data << 4;
    PORTB |= (1<<EN);
    _delay_ms(1);
    PORTB &= ~(1<<EN);
}

void lcd_init() {
    DDRD = 0xFF;
    DDRB = 0xFF;
    PORTB &= ~(1<<EN);
    lcdcmd(0x33);
    lcdcmd(0x32);
    lcdcmd(0x28); //lcd in 4 bit configuration
    lcdcmd(0x0E); //display on cursor on
    lcdcmd(0x01); //clear lcd
    _delay_ms(2);
}

void lcd_print_float(float value) {
    char buffer[20];
    dtostrf(value, 5, 2, buffer); // Convert float to string with 5 digits, 2 decimal places
    lcd_print(buffer);
}

void lcd_print(char *str) {
    unsigned char i=0;
    while(str[i]!=0) {
        lcddata(str[i]);
        i++;
    }
}

int main() {
    float celsius;
    char Temperature[10]; // Array to store temperature as a string

    lcd_init();
    ADC_Init();
   
    while (1) {
        celsius = (ADC_Read(0) * 0.488); // Adjusted conversion factor
        lcdcmd(0x80); // Move cursor to the beginning of the first line
        lcd_print_float(celsius);
        _delay_ms(1000); // Delay for better readability, adjust as needed
    }
    return 0;
}


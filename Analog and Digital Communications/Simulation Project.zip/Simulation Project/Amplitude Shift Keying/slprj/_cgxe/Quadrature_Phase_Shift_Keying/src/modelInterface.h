/* Model Interface Include files */

#include "Quadrature_Phase_Shift_Keying_cgxe.h"
